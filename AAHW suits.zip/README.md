AAHW Suits

Requires x753's More Suits mod. Install via mod manager or by dragging into the Lethal Company directory.

this mod for now only has 1 suit, im testing to see if the mod works, the mod is made for me and my buddys, but feel free to use it, if you use assets credit the original creator.